# 🎼 Adoração & Harmonia — cadastro de hinos

Tela para cadastrar hinos (nome, categoria e letra) e os áudios de cada voz:
Todos, Primeira voz, Soprano, Contralto, Tenor, Baixo e Metrônomo.

## Como rodar

Precisa do **Node 18+**. Abra dois terminais:

**1. Backend (API)**
```bash
cd backend
npm install
npm start
```
Roda em http://localhost:3001

**2. Frontend (React)**
```bash
cd frontend
npm install
npm run dev
```
Abra http://localhost:5173

## Onde ficam os dados

- Hinos: `backend/data/hinos.json`
- Categorias: `backend/data/categories.json` (criado na primeira execução com 3 exemplos — edite os nomes ou crie novas pela tela em “+ Nova categoria…”)
- Áudios enviados: `backend/uploads/`

Cada hino é salvo assim (o `id` é gerado sozinho):
```json
{
  "id": 1,
  "categoria": 1,
  "nomeHino": "3. Belo Tu és",
  "letra": "Esplêndido, esplêndido, é Teu amor fiel! ...",
  "vozes": {
    "todos": "http://localhost:3001/uploads/1727...-todos.mp3",
    "primeiraVoz": "",
    "soprano": "https://link-colado.com/soprano.mp3",
    "contralto": "",
    "tenor": "",
    "baixo": "",
    "metronomo": ""
  }
}
```

Cada categoria:
```json
{ "id": 1, "nome": "Adoração", "ordem": 1, "ativa": true }
```
- `ordem`: posição no dropdown
- `ativa`: coloque `false` para esconder a categoria sem apagar (hinos antigos continuam apontando para ela)

O campo `categoria` do hino guarda o `id` da categoria.

Cada voz aceita **um arquivo de áudio** (clique ou arraste) **ou um link** colado.

## API

| Método | Rota             | O que faz          |
|--------|------------------|--------------------|
| GET    | /api/categories  | Lista as categorias ativas |
| POST   | /api/categories  | Cria categoria (`{ "nome": "..." }`) |
| GET    | /api/hinos       | Lista os hinos     |
| POST   | /api/hinos       | Cria um hino (multipart/form-data) |
| PUT    | /api/hinos/:id   | Edita um hino (multipart/form-data) |
| DELETE | /api/hinos/:id   | Exclui um hino     |

Para usar outra URL de API no front, crie `frontend/.env` com `VITE_API_URL=http://seu-servidor:3001`.

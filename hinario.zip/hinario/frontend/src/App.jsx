import { useEffect, useMemo, useRef, useState } from "react";
import logo from "./assets/logo.png";

const API = import.meta.env.VITE_API_URL || "http://localhost:3001";

const VOZES = [
  { chave: "todos", nome: "Todos" },
  { chave: "primeiraVoz", nome: "Primeira voz" },
  { chave: "soprano", nome: "Soprano" },
  { chave: "contralto", nome: "Contralto" },
  { chave: "tenor", nome: "Tenor" },
  { chave: "baixo", nome: "Baixo" },
  { chave: "metronomo", nome: "Metrônomo" },
];

const NOVA_CATEGORIA = "__nova__";

// arquivo: novo arquivo escolhido | link: link colado | atual: áudio já salvo (edição)
const vozesVazias = () =>
  Object.fromEntries(VOZES.map((v) => [v.chave, { arquivo: null, link: "", preview: "", atual: "" }]));

const formVazio = { nomeHino: "", categoria: "", letra: "" };

export default function App() {
  const [form, setForm] = useState(formVazio);
  const [vozes, setVozes] = useState(vozesVazias);
  const [hinos, setHinos] = useState([]);
  const [categorias, setCategorias] = useState([]);
  const [editandoId, setEditandoId] = useState(null);
  const [busca, setBusca] = useState("");
  const [salvando, setSalvando] = useState(false);
  const [aviso, setAviso] = useState(null); // { tipo: "ok" | "erro", texto }
  const [novaCategoria, setNovaCategoria] = useState(null); // null = fechado, string = digitando

  useEffect(() => {
    carregar();
  }, []);

  async function carregar() {
    try {
      const [resHinos, resCats] = await Promise.all([fetch(`${API}/api/hinos`), fetch(`${API}/api/categories`)]);
      setHinos(await resHinos.json());
      setCategorias(await resCats.json());
    } catch {
      mostrarAviso("erro", "Não foi possível falar com o servidor. Verifique se o backend está rodando na porta 3001.");
    }
  }

  const nomeCategoria = (id) => categorias.find((c) => c.id === Number(id))?.nome ?? `Categoria ${id}`;

  const hinosFiltrados = useMemo(() => {
    const termo = busca.trim().toLowerCase();
    const lista = [...hinos].reverse();
    if (!termo) return lista;
    return lista.filter(
      (h) => h.nomeHino.toLowerCase().includes(termo) || nomeCategoria(h.categoria).toLowerCase().includes(termo)
    );
  }, [hinos, busca, categorias]);

  function mostrarAviso(tipo, texto) {
    setAviso({ tipo, texto });
  }

  const atualizarCampo = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  function escolherCategoria(e) {
    if (e.target.value === NOVA_CATEGORIA) {
      setNovaCategoria("");
      return;
    }
    setForm({ ...form, categoria: e.target.value });
  }

  async function criarCategoria() {
    const nome = novaCategoria?.trim();
    if (!nome) return;
    try {
      const res = await fetch(`${API}/api/categories`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.erro);
      setCategorias((lista) => [...lista, json]);
      setForm((f) => ({ ...f, categoria: String(json.id) }));
      setNovaCategoria(null);
    } catch (err) {
      mostrarAviso("erro", err.message || "Não foi possível criar a categoria.");
    }
  }

  function atualizarVoz(chave, dados) {
    setVozes((atual) => {
      const anterior = atual[chave];
      if (dados.preview !== undefined && anterior.preview.startsWith("blob:")) URL.revokeObjectURL(anterior.preview);
      return { ...atual, [chave]: { ...anterior, ...dados } };
    });
  }

  function limparFormulario() {
    Object.values(vozes).forEach((v) => v.preview.startsWith("blob:") && URL.revokeObjectURL(v.preview));
    setForm(formVazio);
    setVozes(vozesVazias());
    setEditandoId(null);
    setNovaCategoria(null);
  }

  function abrirHino(hino) {
    limparFormulario();
    setEditandoId(hino.id);
    setForm({ nomeHino: hino.nomeHino, categoria: String(hino.categoria), letra: hino.letra });
    setVozes(
      Object.fromEntries(
        VOZES.map((v) => [v.chave, { arquivo: null, link: "", preview: "", atual: hino.vozes?.[v.chave] || "" }])
      )
    );
    setAviso(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const vozesPreenchidas = VOZES.filter((v) => {
    const voz = vozes[v.chave];
    return voz.arquivo || voz.atual || voz.link.trim();
  }).length;

  async function salvar(e) {
    e.preventDefault();
    setAviso(null);

    if (!form.nomeHino.trim() || !form.categoria || !form.letra.trim()) {
      mostrarAviso("erro", "Preencha o nome do hino, a categoria e a letra para salvar.");
      return;
    }

    const dados = new FormData();
    dados.append("nomeHino", form.nomeHino);
    dados.append("categoria", form.categoria);
    dados.append("letra", form.letra);
    for (const { chave } of VOZES) {
      const voz = vozes[chave];
      if (voz.arquivo) dados.append(chave, voz.arquivo);
      else if (voz.atual) dados.append(`${chave}Link`, voz.atual);
      else if (voz.link.trim()) dados.append(`${chave}Link`, voz.link.trim());
    }

    setSalvando(true);
    try {
      const url = editandoId ? `${API}/api/hinos/${editandoId}` : `${API}/api/hinos`;
      const res = await fetch(url, { method: editandoId ? "PUT" : "POST", body: dados });
      const json = await res.json();
      if (!res.ok) throw new Error(json.erro);

      setHinos((lista) => (editandoId ? lista.map((h) => (h.id === json.id ? json : h)) : [...lista, json]));
      mostrarAviso("ok", editandoId ? `“${json.nomeHino}” foi atualizado.` : `“${json.nomeHino}” foi salvo com o id ${json.id}.`);
      limparFormulario();
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      mostrarAviso("erro", err.message || "Não foi possível salvar o hino.");
    } finally {
      setSalvando(false);
    }
  }

  async function excluir() {
    const hino = hinos.find((h) => h.id === editandoId);
    if (!hino || !confirm(`Excluir “${hino.nomeHino}”? Essa ação não pode ser desfeita.`)) return;
    const res = await fetch(`${API}/api/hinos/${hino.id}`, { method: "DELETE" });
    if (!res.ok) return mostrarAviso("erro", "Não foi possível excluir o hino.");
    setHinos((lista) => lista.filter((h) => h.id !== hino.id));
    limparFormulario();
    mostrarAviso("ok", `“${hino.nomeHino}” foi excluído.`);
  }

  return (
    <div className="app">
      <header className="topo">
        <div className="topo-conteudo">
          <div className="marca">
            <img src={logo} alt="Adoração & Harmonia" className="logo" />
            <div>
              <h1>Adoração & Harmonia</h1>
              <p>Cadastro de hinos e vozes</p>
            </div>
          </div>
          <span className="contador">
            {hinos.length} {hinos.length === 1 ? "hino salvo" : "hinos salvos"}
          </span>
        </div>
      </header>

      <div className="pagina">
        {aviso && (
          <div className={`aviso aviso-${aviso.tipo}`} role="status">
            <span>{aviso.texto}</span>
            <button type="button" onClick={() => setAviso(null)} aria-label="Fechar aviso">×</button>
          </div>
        )}

        <main className="grade">
          <form className="formulario" onSubmit={salvar}>
            {editandoId && (
              <div className="faixa-edicao">
                <span>
                  Editando <strong>{form.nomeHino || "hino"}</strong> <span className="faixa-id">#{editandoId}</span>
                </span>
                <button type="button" onClick={limparFormulario}>Cancelar edição</button>
              </div>
            )}

            <section className="bloco">
              <div className="bloco-titulo">
                <span className="passo">1</span>
                <div>
                  <h2>Dados do hino</h2>
                  <p>O id é criado automaticamente.</p>
                </div>
              </div>

              <div className="linha">
                <label className="campo campo-nome">
                  <span>Nome do hino</span>
                  <input name="nomeHino" value={form.nomeHino} onChange={atualizarCampo} placeholder="Ex.: 3. Belo Tu és" />
                </label>

                <div className="campo campo-cat">
                  <label htmlFor="categoria">Categoria</label>
                  {novaCategoria === null ? (
                    <div className="select">
                      <select id="categoria" value={form.categoria} onChange={escolherCategoria}>
                        <option value="" disabled>
                          {categorias.length ? "Escolha uma categoria" : "Nenhuma categoria cadastrada"}
                        </option>
                        {categorias.map((c) => (
                          <option key={c.id} value={c.id}>{c.nome}</option>
                        ))}
                        <option value={NOVA_CATEGORIA}>+ Nova categoria…</option>
                      </select>
                    </div>
                  ) : (
                    <div className="nova-categoria">
                      <input
                        id="categoria"
                        autoFocus
                        value={novaCategoria}
                        onChange={(e) => setNovaCategoria(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") { e.preventDefault(); criarCategoria(); }
                          if (e.key === "Escape") setNovaCategoria(null);
                        }}
                        placeholder="Nome da categoria"
                      />
                      <button type="button" className="mini mini-cheio" onClick={criarCategoria}>Criar</button>
                      <button type="button" className="mini" onClick={() => setNovaCategoria(null)} aria-label="Cancelar">×</button>
                    </div>
                  )}
                </div>
              </div>

              <label className="campo">
                <span>Letra</span>
                <textarea
                  name="letra"
                  value={form.letra}
                  onChange={atualizarCampo}
                  rows={10}
                  placeholder={"Esplêndido, esplêndido, é Teu amor fiel!\nTua graça lá na cruz me redimiu!\n\nCoro:\nBelo Tu és, Te amo!"}
                />
                <small>{form.letra.length} caracteres</small>
              </label>
            </section>

            <section className="bloco">
              <div className="bloco-titulo">
                <span className="passo">2</span>
                <div>
                  <h2>Vozes</h2>
                  <p>Envie um áudio ou cole um link. Todas são opcionais.</p>
                </div>
                <span className="progresso">{vozesPreenchidas}/{VOZES.length}</span>
              </div>

              <div className="vozes">
                {VOZES.map((v) => (
                  <CampoVoz key={v.chave} voz={v} valor={vozes[v.chave]} onChange={(d) => atualizarVoz(v.chave, d)} />
                ))}
              </div>
            </section>

            <div className="acoes">
              {editandoId ? (
                <button type="button" className="botao botao-perigo" onClick={excluir}>Excluir hino</button>
              ) : (
                <button type="button" className="botao botao-leve" onClick={limparFormulario}>Limpar</button>
              )}
              <button type="submit" className="botao botao-principal" disabled={salvando}>
                {salvando ? "Salvando…" : editandoId ? "Salvar alterações" : "Salvar hino"}
              </button>
            </div>
          </form>

          <aside className="lista">
            <div className="lista-topo">
              <h2>Hinos salvos</h2>
              {editandoId && (
                <button type="button" className="mini mini-cheio" onClick={limparFormulario}>+ Novo</button>
              )}
            </div>
            {hinos.length > 0 && (
              <input
                className="busca"
                type="search"
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
                placeholder="Buscar por nome ou categoria"
              />
            )}
            {hinos.length === 0 ? (
              <p className="vazio">Nenhum hino ainda. Preencha o formulário ao lado para salvar o primeiro.</p>
            ) : hinosFiltrados.length === 0 ? (
              <p className="vazio">Nenhum hino encontrado para “{busca}”.</p>
            ) : (
              <ul>
                {hinosFiltrados.map((h) => (
                  <li key={h.id}>
                    <button
                      type="button"
                      className={`item ${editandoId === h.id ? "ativo" : ""}`}
                      onClick={() => abrirHino(h)}
                      title="Abrir para editar"
                    >
                      <span className="item-nome">{h.nomeHino}</span>
                      <span className="item-cat">{nomeCategoria(h.categoria)}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </aside>
        </main>
      </div>
    </div>
  );
}

function CampoVoz({ voz, valor, onChange }) {
  const inputRef = useRef(null);
  const [arrastando, setArrastando] = useState(false);
  const preenchida = valor.arquivo || valor.atual || valor.link.trim();

  function escolherArquivo(arquivo) {
    if (!arquivo) return;
    if (!arquivo.type.startsWith("audio/")) {
      alert("Esse arquivo não é um áudio. Use mp3, wav, m4a ou ogg.");
      return;
    }
    onChange({ arquivo, link: "", atual: "", preview: URL.createObjectURL(arquivo) });
  }

  function limpar() {
    onChange({ arquivo: null, link: "", atual: "", preview: "" });
    if (inputRef.current) inputRef.current.value = "";
  }

  const tocando = valor.arquivo ? valor.preview : valor.atual;

  return (
    <div
      className={`voz voz-${voz.chave} ${preenchida ? "preenchida" : ""} ${arrastando ? "arrastando" : ""}`}
      onDragOver={(e) => { e.preventDefault(); setArrastando(true); }}
      onDragLeave={() => setArrastando(false)}
      onDrop={(e) => { e.preventDefault(); setArrastando(false); escolherArquivo(e.dataTransfer.files[0]); }}
    >
      <div className="voz-info">
        <span className="voz-cor" aria-hidden="true" />
        <strong>{voz.nome}</strong>
      </div>

      <div className="voz-entrada">
        {tocando ? (
          <div className="voz-arquivo">
            <audio controls preload="none" src={tocando} />
            <div className="voz-arquivo-rodape">
              <span title={valor.arquivo?.name || valor.atual}>
                {valor.arquivo ? valor.arquivo.name : "Áudio salvo"}
              </span>
              <div>
                <button type="button" className="trocar" onClick={() => inputRef.current?.click()}>Trocar</button>
                <button type="button" onClick={limpar}>Remover</button>
              </div>
            </div>
          </div>
        ) : (
          <div className="voz-opcoes">
            <button type="button" className="botao-arquivo" onClick={() => inputRef.current?.click()}>
              Escolher áudio
            </button>
            <input
              type="url"
              placeholder="ou cole um link"
              title="Cole o link do áudio"
              value={valor.link}
              onChange={(e) => onChange({ link: e.target.value })}
            />
            {valor.link && (
              <button type="button" className="limpar-link" onClick={limpar} aria-label="Apagar link">×</button>
            )}
          </div>
        )}
        <input ref={inputRef} type="file" accept="audio/*" hidden onChange={(e) => escolherArquivo(e.target.files[0])} />
      </div>
    </div>
  );
}

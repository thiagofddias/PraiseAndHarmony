import express from "express";
import cors from "cors";
import multer from "multer";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3001;
const DATA_DIR = path.join(__dirname, "data");
const UPLOAD_DIR = path.join(__dirname, "uploads");

// Vozes aceitas (mesmas chaves usadas no front)
const VOZES = ["todos", "primeiraVoz", "soprano", "contralto", "tenor", "baixo", "metronomo"];

// ---------- "Banco" em arquivos JSON (uma tabela por arquivo) ----------
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// Categorias iniciais — troque pelos nomes reais ou cadastre pela tela
const CATEGORIAS_INICIAIS = [
  { id: 1, nome: "Adoração", ordem: 1, ativa: true },
  { id: 2, nome: "Louvor", ordem: 2, ativa: true },
  { id: 3, nome: "Hinos tradicionais", ordem: 3, ativa: true },
];

const tabela = (nome, inicial = []) => {
  const arquivo = path.join(DATA_DIR, `${nome}.json`);
  if (!fs.existsSync(arquivo)) fs.writeFileSync(arquivo, JSON.stringify(inicial, null, 2));
  return {
    ler: () => JSON.parse(fs.readFileSync(arquivo, "utf-8")),
    salvar: (dados) => fs.writeFileSync(arquivo, JSON.stringify(dados, null, 2)),
  };
};

const hinosDb = tabela("hinos");
const categoriesDb = tabela("categories", CATEGORIAS_INICIAIS);
const proximoId = (lista) => lista.reduce((max, item) => Math.max(max, item.id), 0) + 1;

// ---------- Upload de áudios ----------
const storage = multer.diskStorage({
  destination: UPLOAD_DIR,
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || ".mp3";
    cb(null, `${Date.now()}-${file.fieldname}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50 MB por arquivo
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("audio/")) cb(null, true);
    else cb(new Error("Envie apenas arquivos de áudio (mp3, wav, m4a...)."));
  },
});
const uploadVozes = upload.fields(VOZES.map((name) => ({ name, maxCount: 1 })));

const apagarArquivo = (url) => {
  if (url && url.includes("/uploads/")) {
    fs.rm(path.join(UPLOAD_DIR, path.basename(url)), { force: true }, () => {});
  }
};

// Monta o objeto de vozes: arquivo novo > link/URL mantida > vazio
function montarVozes(req, vozesAntigas = {}) {
  const base = `${req.protocol}://${req.get("host")}`;
  const vozes = {};
  for (const voz of VOZES) {
    const arquivo = req.files?.[voz]?.[0];
    const link = req.body[`${voz}Link`]?.trim() || "";
    vozes[voz] = arquivo ? `${base}/uploads/${arquivo.filename}` : link;
    // se o áudio antigo foi trocado ou removido, apaga o arquivo do disco
    if (vozesAntigas[voz] && vozesAntigas[voz] !== vozes[voz]) apagarArquivo(vozesAntigas[voz]);
  }
  return vozes;
}

function validarHino(body) {
  const { nomeHino, categoria, letra } = body;
  if (!nomeHino?.trim() || !letra?.trim() || !categoria) {
    return "Preencha nome do hino, categoria e letra.";
  }
  if (!categoriesDb.ler().some((c) => c.id === Number(categoria))) {
    return "Categoria não encontrada.";
  }
  return null;
}

const app = express();
app.use(cors());
app.use(express.json());
app.use("/uploads", express.static(UPLOAD_DIR));

// ---------- Categories ----------
app.get("/api/categories", (req, res) => {
  const lista = categoriesDb.ler().filter((c) => c.ativa !== false);
  res.json(lista.sort((a, b) => (a.ordem ?? a.id) - (b.ordem ?? b.id)));
});

app.post("/api/categories", (req, res) => {
  const nome = req.body.nome?.trim();
  if (!nome) return res.status(400).json({ erro: "Informe o nome da categoria." });

  const lista = categoriesDb.ler();
  if (lista.some((c) => c.nome.toLowerCase() === nome.toLowerCase())) {
    return res.status(409).json({ erro: "Já existe uma categoria com esse nome." });
  }
  const id = proximoId(lista);
  const categoria = { id, nome, ordem: id, ativa: true };
  lista.push(categoria);
  categoriesDb.salvar(lista);
  res.status(201).json(categoria);
});

// ---------- Hinos ----------
app.get("/api/hinos", (req, res) => {
  res.json(hinosDb.ler());
});

app.post("/api/hinos", uploadVozes, (req, res) => {
  const erro = validarHino(req.body);
  if (erro) return res.status(400).json({ erro });

  const hinos = hinosDb.ler();
  const hino = {
    id: proximoId(hinos),
    categoria: Number(req.body.categoria),
    nomeHino: req.body.nomeHino.trim(),
    letra: req.body.letra.trim(),
    vozes: montarVozes(req),
  };
  hinos.push(hino);
  hinosDb.salvar(hinos);
  res.status(201).json(hino);
});

app.put("/api/hinos/:id", uploadVozes, (req, res) => {
  const id = Number(req.params.id);
  const hinos = hinosDb.ler();
  const indice = hinos.findIndex((h) => h.id === id);
  if (indice === -1) return res.status(404).json({ erro: "Hino não encontrado." });

  const erro = validarHino(req.body);
  if (erro) return res.status(400).json({ erro });

  const antigo = hinos[indice];
  hinos[indice] = {
    ...antigo,
    categoria: Number(req.body.categoria),
    nomeHino: req.body.nomeHino.trim(),
    letra: req.body.letra.trim(),
    vozes: montarVozes(req, antigo.vozes),
  };
  hinosDb.salvar(hinos);
  res.json(hinos[indice]);
});

app.delete("/api/hinos/:id", (req, res) => {
  const id = Number(req.params.id);
  const hinos = hinosDb.ler();
  const hino = hinos.find((h) => h.id === id);
  if (!hino) return res.status(404).json({ erro: "Hino não encontrado." });

  Object.values(hino.vozes || {}).forEach(apagarArquivo);
  hinosDb.salvar(hinos.filter((h) => h.id !== id));
  res.status(204).end();
});

// Erros (ex.: arquivo que não é áudio, arquivo grande demais)
app.use((err, req, res, next) => {
  res.status(400).json({ erro: err.message || "Não foi possível processar o envio." });
});

app.listen(PORT, () => console.log(`🎼 API rodando em http://localhost:${PORT}`));
